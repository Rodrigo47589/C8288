import { rutaHello, rutaAPINames } from "./routes.js";
import express from "express";

const server = express();
const port = 3000;
server.get("/hello", function (req, res) {
    const response = rutaHello(req, res);
    res.send(response);
});

server.get("/api/names", async function (req, res) {
    let response;
    try {
        response = await rutaAPINames(req,res);
    }catch (err) {
        console.log(err);
    }

    res.send(response);

});

server.listen(port, function(){

    console.log("Listening on" + port);

});